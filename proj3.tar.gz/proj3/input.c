/* Test file for Project III, 100% level, CSCE 531 */

/* There are no errors in this file */

int a,b,c,i,j;
float z;

int main4(), setx36(), main5(), setx37();
int print_one(), print_two(), print_three(), print_dunno();
int print_even(), print_odd(), print_nl();
int print_just(), print_isnt(), print_j(), print_i_j_values();

main()  {

    a = 9;
    b = 3;
    c = 1;

    switch(a)  {
        case 1:     print_one();
        case 2:     print_two();
        case 3:     print_three();
    }

    switch(a)  {
        case 1:     print_one();
        case 2:     print_two();
        case 3:     print_three();
        default:    print_dunno();
    }

    a = 2;

    switch(a)  {
        case 1:     print_one();
        case 2:     print_two();
        case 3:     print_three();
        default:    print_dunno();
    }

    switch(a)  {
        case 1:     print_one(); break;
        case 2:     print_two(); break;
        case 3:     print_three(); break;
        default:    print_dunno();
    }

    switch(c)  {
        default:    print_just();
    }
}