
/****************************************************************/
/*								*/
/*	CSCE531 - "Pascal" and "C" Compilers			*/
/*								*/
/*	--utils.c--						*/
/*								*/
/*	This file contains utility routines for the CSCE531	*/
/*	Pascal and C compilers.					*/
/*								*/
/*								*/
/*								*/
/****************************************************************/

#include <stdarg.h>
#include <stdlib.h>
#include "defs.h"
#include "types.h"
#include "symtab.h"
#include "message.h"
/* defined in defs.h */
#include BACKEND_HEADER_FILE
#include <string.h>



TNODE* root = NULL;

/****************************************************************/
/*
	interface to scanner to get line numbers for error messages
*/

int sc_line()
{
	extern int yylineno;

	return yylineno;
}

/****************************************************************/
/*
	support for parameter lists
*/
PARAM_LIST plist_alloc()
{
	return (PARAM_LIST) malloc(sizeof(PARAM));
}

void plist_free(PARAM_LIST plist)
{
    free(plist);
}

/****************************************************************/
/*
	support for symbol table data records
*/

void stdr_free(ST_DR stdr)
{
	free(stdr);
}

ST_DR stdr_alloc()
{
	return (ST_DR) malloc(sizeof(ST_DATA_REC));
}

void stdr_dump(ST_DR stdr)
{
	extern void print_boolean(BOOLEAN);

	if (stdr == NULL)
	{
		msg("<null>");
		return;
	}
	switch(stdr->tag) {
	case ECONST:	msg("	ECONST");
			break;
	case GDECL:	msg("	GDECL");
			break;
	case LDECL:	msg("	LDECL");
			break;
	case PDECL:	msg("	PDECL");
			break;
	case FDECL:	msg("	FDECL");
			break;
	case TAG:	msg("	TAG");
			break;
	case TYPENAME:	msg("	TYPENAME");
			break;
	default:
		bug("illegal tag in \"stdr_dump\""); 
	}
	switch(stdr->tag) {
	case ECONST:	msgn("		type = ");
			ty_print_type(stdr->u.econst.type);
			msg("");
			msg("		value = %d",stdr->u.econst.val);
			break;
	case GDECL:
	case LDECL:
	case PDECL:
	case FDECL:	msgn("		type = ");
			ty_print_type(stdr->u.decl.type);
			msg("");
			msgn("		storage class = ");
			ty_print_class(stdr->u.decl.sc);
			msg("");
			msgn("		reference parameter = ");
			print_boolean(stdr->u.decl.is_ref);
			msg("");
#ifdef PASCAL_LANG
			if (stdr->tag == LDECL || stdr->tag == PDECL)
			    msg("		offset = %d",
				stdr->u.decl.v.offset);
			else if (stdr->tag == FDECL)
			    msg("		global function name = \"%s\"",
				stdr->u.decl.v.global_func_name);
#endif
			msgn("		error = ");
			print_boolean(stdr->u.decl.err);
			msg("");
			break;
	case TAG:	msgn("		type = ");
			ty_print_type(stdr->u.stag.type);
			msg("");
			break;
	case TYPENAME:	msgn("		type = ");
			ty_print_type(stdr->u.typename.type);
			msg("");
			break;
	}
}


/****************************************************************/
/*
	support for printing "typedef" types
*/

void print_boolean(BOOLEAN b)
{
	if (b)
		msgn("TRUE");

	else
		msgn("FALSE");
}


/****************************************************************/
/*
	backend support for allocating global variables

	1st arg: the type (TYPETAG)
	2nd arg: the initialization value (dependent on type)
*/

void b_alloc_gdata ( TYPETAG tag, ... )
{
    va_list ap;
    va_start(ap, tag);
    switch (tag) {
    case TYSIGNEDCHAR:
    case TYUNSIGNEDCHAR:
	b_alloc_char(va_arg(ap, int));
	break;
    case TYSIGNEDSHORTINT:
    case TYUNSIGNEDSHORTINT:
	b_alloc_short(va_arg(ap, int));
	break;
    case TYSIGNEDINT:
    case TYUNSIGNEDINT:
	b_alloc_int(va_arg(ap, int));
	break;
    case TYSIGNEDLONGINT:
    case TYUNSIGNEDLONGINT:
	b_alloc_long(va_arg(ap, long));
	break;
    case TYPTR:
	b_alloc_ptr(va_arg(ap, char *));
	break;
    case TYFLOAT:
	b_alloc_float(va_arg(ap, double));
	break;
    case TYDOUBLE:
    case TYLONGDOUBLE:
	b_alloc_double(va_arg(ap, double));
	break;
    default:
	bug("alloc_gdata: cannot allocate global data of this type");
    }
    va_end(ap);
}



/****************************************************************/
/* Note: We cannot just use sizeof() here, because the runtime  */
/*       memory model may differ from the compile-time memory   */
/*       model.  Currently, we assume the 32-bit x86 model.     */
/****************************************************************/
unsigned int get_size_basic(TYPETAG tag)
{
    switch (tag) {
    case TYSIGNEDCHAR:
    case TYUNSIGNEDCHAR:
	return 1;
    case TYSIGNEDSHORTINT:
    case TYUNSIGNEDSHORTINT:
	return 2;
    case TYSIGNEDINT:
    case TYUNSIGNEDINT:
    case TYENUM:
	return 4;
    case TYSIGNEDLONGINT:
    case TYUNSIGNEDLONGINT:
	return 4;
    case TYPTR:
	return 4;     /* this is for 32-bit, which differs from 64-bit */
    case TYFLOAT:
	return 4;
    case TYDOUBLE:
    case TYLONGDOUBLE:
	return 8;
    case TYVOID:
	return sizeof(void);
    case TYFUNC:
        bug("get_size_basic: TYFUNC is not a data type");
    case TYERROR:
        bug("get_size_basic: TYERROR is not a data type");
    default:
	bug("get_size_basic: nonbasic or unknown type: %d", tag);
    }
}



/*
void add_node(NODE *node) {
	if(root == NULL)
		root = current = node; 	
	else {
		current-> link = node;
		current = current->link;	
	}
	/*if(node->type == VARIABLE)
	{
		printf("varaible1 : %s \n",node->u.name);
	}
}
*/
/*
NODE* remove_node(NODE *root) {
	if(root == NULL)
		return NULL;
	NODE *temp = root;
	root = root->link;
	temp->link = NULL;
	return temp;
}
*/

NODE* create_node() {
	NODE *temp = (NODE*) malloc(sizeof(NODE));
	temp->link = NULL;	
	return temp;
}

/*
void print_list(NODE *temp){
	while(temp != NULL) {
		if(temp->type == VARIABLE) {
			printf("varaible : %s \n",st_get_id_str(temp->u.id));		
		}
		if(temp->type == PTR) {
			printf("pointer \n");		
		}
		if(temp->type == EMPTY_FUNCTION) {
			printf("function \n");		
		}
		if(temp->type == ARRAY_SUBSCRIPT) {
			printf("array subscript & size : %d \n",temp->u.size);
		}
		temp = temp->link;
	}
}
*/

void do_backend_stuff(TYPE type, int *size, int *alignment)
{
	TYPETAG type_tag = ty_query(type);
	
	if(type_tag == TYUNSIGNEDCHAR || type_tag == TYSIGNEDCHAR)
   	{
      		*size = 1;
      		*alignment = 1;
   	}
	if(type_tag == TYSIGNEDSHORTINT || type_tag == TYUNSIGNEDSHORTINT)
   	{
      		*size = 2;
      		*alignment = 2;
   	}
	if(type_tag == TYUNSIGNEDINT || type_tag == TYSIGNEDINT || type_tag == TYPTR || type_tag == TYFLOAT)
   	{
      		*size = 4;
      		*alignment = 4;
   	}
   	if(type_tag == TYDOUBLE || type_tag == TYUNSIGNEDLONGINT || type_tag == TYSIGNEDLONGINT)
   	{
      		*size = 8;
      		*alignment = 8;
   	}
	if(type_tag == TYLONGDOUBLE)
   	{
      		*size = 10;
      		*alignment = 10;
   	}
   	if(type_tag == TYARRAY)
   	{
		int align,size_r,dim;		
		DIMFLAG dimflag;
		TYPE typearr = ty_query_array(type,&dimflag,&dim);
      		do_backend_stuff(typearr, &size_r, &align);
		*alignment = align;
         	*size = size_r * dim;
   	}
}

void install_token(TYPE type, NODE *root) {
	NODE *temp = root;
	while(temp != NULL) {
		switch(temp->type) {
			ST_DR st_dr;
			case PTR: 
				type = ty_build_ptr(type, NO_QUAL);		
				break;
			case FUNCTION:
				type = ty_build_func(type,PROTOTYPE,NULL);
				break;
			case ARRAY:
				if(temp->u.size <= 0)
					error("illegal array dimension");
				type = ty_build_array(type,DIM_PRESENT,temp->u.size);
				//printf("array subscript & size : %d \n",temp->u.size);
				break;
			case VAR: 
				st_dr = stdr_alloc();
				st_dr->tag = GDECL;
				st_dr->u.decl.type = type;
				st_dr->u.decl.sc = NO_SC;
				st_dr->u.decl.is_ref = FALSE;
        			char *name = st_get_id_str(temp->u.id);
				TYPETAG type_tag=ty_query(type);
				create_tnode(name,type_tag);
				if(type_tag == TYERROR)
				{
				    st_dr->u.decl.err = TRUE;
				}
				else
				{
				   st_dr->u.decl.err = FALSE;
				}
				if(!st_install(temp->u.id,st_dr)) {
					error("duplicate declaration for %s",name);
					error("duplicate definition of `%s'",name);
				}
				int alignment = 0;
				int size = 0;
				do_backend_stuff(st_dr->u.decl.type, &size, &alignment);
				if(type_tag != TYERROR && type_tag != TYFUNC)
				{
					b_global_decl(name,alignment,size);
					b_skip(size);
				}
				break;
			}			
			root=root->link;
			//free(temp);
			temp = root;
		}
}

NODE* build_ptr_node() {
	NODE *new_node = create_node();
	new_node->type = PTR;
	return new_node;
}

EXPR* make_binop_node(BINOP_TYPE op, EXPR* left, EXPR* right) {
		EXPR* node = (EXPR*)malloc(sizeof(EXPR));
		node->tag = BINOP_EXPR;
        node->u.BINOP.op = op;
        node->u.BINOP.left = left;
        node->u.BINOP.right = right;
		return node;
}

EXPR* const_folding_GT(EXPR* left, EXPR* right) {
	int is_folded = 0;
	EXPR* node = (EXPR*)malloc(sizeof(EXPR));
    node->tag = ICONST_EXPR;
    
	if( (left->tag == ICONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val > right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == ICONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val > right->u.DCONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val > right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val > right->u.DCONST.val; 
			is_folded = 1;
    }
	if(is_folded)
		return node;
	return NULL;                                            
}

EXPR* const_folding_LT(EXPR* left, EXPR* right) {
	int is_folded = 0;
	EXPR* node = (EXPR*)malloc(sizeof(EXPR));
    node->tag = ICONST_EXPR;
    
	if( (left->tag == ICONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val < right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == ICONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val < right->u.DCONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val < right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val < right->u.DCONST.val; 
			is_folded = 1;
    }
	if(is_folded)
		return node;
	return NULL;                                            
}

EXPR* const_folding_GE(EXPR* left, EXPR* right) {
	int is_folded = 0;
	EXPR* node = (EXPR*)malloc(sizeof(EXPR));
    node->tag = ICONST_EXPR;
    
	if( (left->tag == ICONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val >= right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == ICONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val >= right->u.DCONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val >= right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val >= right->u.DCONST.val; 
			is_folded = 1;
    }
	if(is_folded)
		return node;
	return NULL;                                            
}

EXPR* const_folding_LE(EXPR* left, EXPR* right) {
	int is_folded = 0;
	EXPR* node = (EXPR*)malloc(sizeof(EXPR));
    node->tag = ICONST_EXPR;
    
	if( (left->tag == ICONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val <= right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == ICONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val <= right->u.DCONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val <= right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val <= right->u.DCONST.val; 
			is_folded = 1;
    }
	if(is_folded)
		return node;
	return NULL;                                            
}

EXPR* const_folding_EQ(EXPR* left, EXPR* right) {
	int is_folded = 0;
	EXPR* node = (EXPR*)malloc(sizeof(EXPR));
    node->tag = ICONST_EXPR;
    
	if( (left->tag == ICONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val == right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == ICONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val == right->u.DCONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val == right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val == right->u.DCONST.val; 
			is_folded = 1;
    }
	if(is_folded)
		return node;
	return NULL;                                            
}

EXPR* const_folding_NE(EXPR* left, EXPR* right) {
	int is_folded = 0;
	EXPR* node = (EXPR*)malloc(sizeof(EXPR));
    node->tag = ICONST_EXPR;
    
	if( (left->tag == ICONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val != right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == ICONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.ICONST.val != right->u.DCONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == ICONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val != right->u.ICONST.val; 
			is_folded = 1;
    }
	else if( (left->tag == DCONST_EXPR) &&  (right->tag == DCONST_EXPR) ) {
		    node->u.ICONST.val = left->u.DCONST.val != right->u.DCONST.val; 
			is_folded = 1;
    }
	if(is_folded)
		return node;
	return NULL;                                            
}

extern SNODE* s_stack[10];
extern int s_top;


void add_snode(int no, char* name) {
	SNODE* newnode = (SNODE*)malloc(sizeof(SNODE));
	newnode->case_no = no;
	newnode->label = name;
	newnode->link = NULL;
	if(s_stack[s_top] == NULL)
		s_stack[s_top] = newnode;
	else {
		SNODE* temp = s_stack[s_top];
		while(temp->link != NULL) 
			temp = temp->link;
		temp->link = newnode;
	}
	
}

char* search_label(int no) {
		SNODE* temp = s_stack[s_top];
		while(temp != NULL) {
			if(temp->case_no == no)
				return temp->label;
			temp = temp->link;
		}
	return NULL;
}

create_tnode(char* name, TYPETAG t){
	TNODE* node = (TNODE*)malloc(sizeof(TNODE));
	node->name = name;
	node->type = t;
	node->next = NULL;
	if(root == NULL)
		root = node;
	else {
		TNODE* temp = root;
		while(temp->next != NULL) 
			temp = temp->next;
		temp->next = node;
	}
}

TYPETAG get_token_type(char *name) {
	TNODE* temp = root;
	while(temp != NULL) {
		if(!strcmp(name,temp->name)) {
		//	printf("****%s****%s*****\n",name,temp->name);
			return temp->type;
		}
		temp = temp->next;
	}
	return TYSIGNEDINT; //default type
}
/*
void print_type_list() {
		TNODE* temp = root;
		while(temp != NULL) {
			printf("%s : ",temp->name);
			if(temp->type == TYFUNC)
				printf("tyfunc\n");
			if(temp->type == TYSIGNEDINT)
				printf("tysignedint\n");
			temp = temp->next;
		}
}
*/
TYPETAG get_expr_type(EXPR* root){
	TYPETAG type = TYSIGNEDINT;
	if(root == NULL)
		return type;
	if(root->tag == BINOP_EXPR) {
		TYPETAG type1 = get_expr_type(root->u.BINOP.left);
		TYPETAG type2 = get_expr_type(root->u.BINOP.right);
		//printf("type1, type2 = %d,%d\n",type1,type2);
		if((type1 == TYDOUBLE) || (type2 == TYDOUBLE) || (type1 == TYFLOAT) || (type2 == TYFLOAT))
			type = TYDOUBLE;
		else if((type1 == TYSIGNEDINT) && (type2 == TYSIGNEDINT)) 
			type = TYSIGNEDINT;
		//printf("final type=%d\n",type);
		if(root->u.BINOP.op == GT) {
			type = TYSIGNEDINT;
		}
		if(root->u.BINOP.op == LT) {
			type = TYSIGNEDINT;
		}
		if(root->u.BINOP.op == GE) { 
			type = TYSIGNEDINT;
		}
		if(root->u.BINOP.op == LE) { 
			type = TYSIGNEDINT;
		}
		if(root->u.BINOP.op == EQ) { 
			type = TYSIGNEDINT;
		}
		if(root->u.BINOP.op == NE) {
			type = TYSIGNEDINT;
		}
		return type;
	}
	if(root->tag == ASSIGN_EXPR){
		TYPETAG l_type = get_token_type(root->u.ASSIGN.left->u.VAR.name);
		type = get_expr_type(root->u.ASSIGN.right);
		if(l_type != type ) {
			return l_type;
		}
		return type;
//		printf("assign\n");
	}
	if(root->tag == FUNC_EXPR) {
			return root->u.FUNC.type;
	}
	if(root->tag == UNOP_EXPR) {
		
		type = get_expr_type(root->u.UNOP.right);
		if(type == TYPTR)
			if(root->u.UNOP.right->tag == VAR_EXPR){
				type = find_type_of_ptr(root->u.UNOP.right->u.VAR.name);
					
			}
		return type;
//		printf("Dconst\n");
	}
	if(root->tag == DCONST_EXPR) {
		return TYDOUBLE;
//		printf("Dconst\n");
	}
	if(root->tag == ICONST_EXPR) {
		return TYSIGNEDINT;
//		printf("Iconst\n");
	}
	if(root->tag == VAR_EXPR) {
		TYPETAG token_type = get_token_type(root->u.VAR.name);
			if(token_type == TYSIGNEDCHAR) {
				return TYSIGNEDINT;
			}
			if(token_type == TYFLOAT) {
				return TYDOUBLE;
			}
			return token_type;
	}
	return type;
}

TYPETAG get_type(char* name){
	int block = GDECL;
	ST_DR st_dr = st_lookup(st_enter_id(name),&block);	
	return ty_query(st_dr->u.decl.type);
}

extern int has_error;
TYPETAG l_typ = -10;
TYPETAG p_typ = -10;
//static TYPETAG bl_typ = -10;
//static TYPETAG br_typ = -10;
int is_binary = 0;
			
TYPETAG evaluateExpression(EXPR* root){
	TYPETAG type = TYSIGNEDINT;
	if(root == NULL)
		return type;
	if(root->tag == BINOP_EXPR) {
		is_binary = 1;
		TYPETAG type1 = evaluateExpression(root->u.BINOP.left);
		TYPETAG type2 = get_expr_type(root->u.BINOP.right);
		if(type1 == TYSIGNEDINT && type2 == TYDOUBLE)
			b_convert(type1, type2);
		//is_binary = 1;
		type2 = evaluateExpression(root->u.BINOP.right);
		if((type1 == TYFLOAT)||(type2 == TYSIGNEDCHAR) || (type1 == TYSIGNEDCHAR) || (type2 == TYFLOAT)){
			if(type1==TYFLOAT)
				type1=TYDOUBLE;
			if(type2 == TYFLOAT)
				type2 = TYDOUBLE;
			if(type1==TYSIGNEDCHAR)
				type1=TYSIGNEDINT;
			if(type2 == TYSIGNEDCHAR)
				type2 = TYSIGNEDINT;
		}
		if(type2 == TYSIGNEDINT && type1 == TYDOUBLE)
			b_convert(type2, type1);
		if((type1 == TYDOUBLE) || (type2 == TYDOUBLE) || (type1 == TYFLOAT) || (type2 == TYFLOAT))
			type = TYDOUBLE;
		else if((type1 == TYSIGNEDINT) && (type2 == TYSIGNEDINT)) 
			type = TYSIGNEDINT;
		//printf("bl_typ, br_typ = %d,%d\n",bl_typ,br_typ);
		if((root->u.BINOP.left->tag==VAR_EXPR && root->u.BINOP.right->tag==VAR_EXPR)){
			TYPETAG t1= get_type(root->u.BINOP.left->u.VAR.name);
			TYPETAG t2= get_type(root->u.BINOP.right->u.VAR.name);
			if(t1 == TYPTR && t2 == TYPTR)			
				type=TYPTR;
			else if((t1 == TYPTR && t2 != TYPTR)||((t1 != TYPTR && t2 == TYPTR))){
				if(t1 == TYPTR && t2 != TYPTR)
					b_convert(t2,t1);
				if(t1 != TYPTR && t2 == TYPTR)
					b_convert(t1,t2);
				type=TYPTR;			
			}
		}else if((root->u.BINOP.left->tag==VAR_EXPR && root->u.BINOP.right->tag==ICONST_EXPR)){
			TYPETAG t1= get_type(root->u.BINOP.left->u.VAR.name);
			 if(t1 == TYPTR){
				b_convert(TYSIGNEDINT,t1);
				type=TYPTR;			
			}
		}
		if(root->u.BINOP.op == PLUS)
			b_arith_rel_op(B_ADD,type);
		if(root->u.BINOP.op == MINUS)
			b_arith_rel_op(B_SUB,type);
		if(root->u.BINOP.op == TIMES)
			b_arith_rel_op(B_MULT,type);
		if(root->u.BINOP.op == DIV)
			b_arith_rel_op(B_DIV,type);
		if(root->u.BINOP.op == MOD)
			b_arith_rel_op(B_MOD,type);
		if(root->u.BINOP.op == GT) {
			b_arith_rel_op(B_GT,type);
			type = TYSIGNEDINT;
		}
		if(root->u.BINOP.op == LT) {
			b_arith_rel_op(B_LT,type);
			type = TYSIGNEDINT;
		}
		if(root->u.BINOP.op == GE) { 
			b_arith_rel_op(B_GE,type);
			type = TYSIGNEDINT;
		}
		if(root->u.BINOP.op == LE) { 
			b_arith_rel_op(B_LE,type);
			type = TYSIGNEDINT;
		}
		if(root->u.BINOP.op == EQ) { 
			b_arith_rel_op(B_EQ,type);
			type = TYSIGNEDINT;
		}
		if(root->u.BINOP.op == NE) {
			b_arith_rel_op(B_NE,type);
			type = TYSIGNEDINT;
		}
		return type;
	}
	if(root->tag == ASSIGN_EXPR){
		TYPETAG l_type;
		TYPETAG p_type = -1000;
		if(root->u.ASSIGN.left->tag == VAR_EXPR) {	
			l_type = get_token_type(root->u.ASSIGN.left->u.VAR.name);
			ST_ID id = st_enter_id(root->u.ASSIGN.left->u.VAR.name);
			int block = GDECL;
			ST_DR st_dr = st_lookup(id,&block);
			if(st_dr == NULL) {
				error("`%s' is undefined",root->u.ASSIGN.left->u.VAR.name);
				has_error = 0;
			}
			else if(l_type == TYFUNC) {
				error("left side of assignment is not an l-value");
				has_error = 0;
			}
			b_push_ext_addr(root->u.ASSIGN.left->u.VAR.name);
			if(l_type == TYPTR) {
				l_type = find_type_of_ptr(root->u.ASSIGN.left->u.VAR.name); 
				p_type = TYPTR;			
			}
				
					
		}
		else if(root->u.ASSIGN.left->tag == UNOP_EXPR) {
			EXPR* temp = root->u.ASSIGN.left;
			int ptr_count = 0;
			while(temp->tag == UNOP_EXPR) {
				if(temp->u.UNOP.op_type == U_PTR)
					ptr_count++;
				temp = temp->u.UNOP.right;
			}
			if(temp->tag == VAR_EXPR) {
				b_push_ext_addr(temp->u.VAR.name);
				while(ptr_count) {
					b_deref(TYPTR);
					ptr_count--;
				}	
				l_type = find_type_of_ptr(temp->u.VAR.name); 
				//b_deref(l_type);		
			}	
			
		}
		p_typ = p_type;
		l_typ = l_type;
		int temp_set=0;
		if(p_type==TYPTR && root->u.ASSIGN.right->tag == ICONST_EXPR){
			if(root->u.ASSIGN.right->u.ICONST.val==0)
				temp_set=1;
			else
				temp_set=0;
		}
		type = evaluateExpression(root->u.ASSIGN.right);
		//printf("ltype, type, p_type = %d,%d,%d\n",l_type,type,p_type);
		if(l_type != type ) {
			if(!temp_set)
				b_convert(type,l_type);
			else
				b_convert(type,TYPTR);
			if(p_type == TYPTR)
				b_assign(TYPTR);
			else
				b_assign(l_type);
			return l_type;
		}
		else {
			if(p_type == TYPTR)
				b_assign(TYPTR);
			else
				b_assign(type);
		}		
		return type;
//		printf("assign\n");
	}
	if(root->tag == FUNC_EXPR) {
			b_alloc_arglist(0);				
			b_funcall_by_name(root->u.FUNC.name, root->u.FUNC.type);
			//printf("inside function %d \n",*root->u.FUNC.is_expr);
			if( (root->u.FUNC.type != TYVOID) && (!(*root->u.FUNC.is_expr)) )
				b_pop();
			return root->u.FUNC.type;
	}
	if(root->tag == UNOP_EXPR) {
		if(root->u.UNOP.op_type == U_MINUS) {
			type = evaluateExpression(root->u.UNOP.right);
			b_negate(type);
		}
		else if(root->u.UNOP.op_type == U_AMP) {
			if(root->u.UNOP.right->tag == VAR_EXPR)			
				root->u.UNOP.right->u.VAR.is_amp_ref = 1;
			type = evaluateExpression(root->u.UNOP.right);
		}
		else if(root->u.UNOP.op_type == U_PTR) {
			
			EXPR* temp = root->u.UNOP.right;
			int ptr_count = 1;
			while(temp->tag == UNOP_EXPR) {
				if(temp->u.UNOP.op_type == U_PTR)
					ptr_count++;
				temp = temp->u.UNOP.right;
			}
			if(temp->tag == VAR_EXPR) {
				b_push_ext_addr(temp->u.VAR.name);
				while(ptr_count) {
					b_deref(TYPTR);
					ptr_count--;
				}	
				type = find_type_of_ptr(temp->u.VAR.name); 
				b_deref(type);
				if(type == TYFLOAT)
					b_convert(type,TYDOUBLE);
				if(type == TYSIGNEDCHAR)
					b_convert(type,TYSIGNEDINT);		
			}			
		}
		return type;
//		printf("Dconst\n");
	}
	if(root->tag == DCONST_EXPR) {
		b_push_const_double(root->u.DCONST.val);
		return TYDOUBLE;
//		printf("Dconst\n");
	}
	if(root->tag == ICONST_EXPR) {
		b_push_const_int(root->u.ICONST.val);
		return TYSIGNEDINT;
//		printf("Iconst\n");
	}
	if(root->tag == VAR_EXPR) {
		TYPETAG token_type = get_token_type(root->u.VAR.name);
		if(token_type != TYFUNC) {
			b_push_ext_addr(root->u.VAR.name);
			if(root->u.VAR.is_amp_ref){
				if(token_type==TYPTR){
					token_type=find_type_of_ptr(root->u.VAR.name);
				}	
			}else{
				b_deref(token_type);	
			}
			//printf("current var %s, with type=%d and is_binar=%d\n",root->u.VAR.name,token_type,is_binary);

			if(token_type == TYPTR)
				token_type =find_type_of_ptr(root->u.VAR.name);
			if(token_type == TYSIGNEDCHAR) {
				if((p_typ == TYPTR)) {	
					if(l_typ != token_type)	
						b_convert(token_type, TYSIGNEDINT);
					p_typ = -10; l_typ = -10;
					return token_type;
				}
				if(p_typ == -10) 
					b_convert(token_type, TYSIGNEDINT);
								
				return TYSIGNEDINT;
	 		}
			if(token_type == TYFLOAT) {
						
				if((p_typ == TYPTR) ) {
					if(l_typ != token_type)		
						b_convert(token_type, TYDOUBLE);
					p_typ = -10; l_typ = -10;
					return token_type;
				}
				if(p_typ == -10) 
					b_convert(token_type, TYDOUBLE);
				return TYDOUBLE;
			}
			return token_type;
		}
		return type;
 		// not needed as of now for assign_expr
		//printf("var\n");
}		
}

TYPETAG find_type_of_ptr(char* var_name){
	int block = GDECL;
	ST_DR st_dr = st_lookup(st_enter_id(var_name),&block);
	TYPE_QUALIFIER type_quali;	
	TYPE type=ty_query_pointer(st_dr->u.decl.type,&type_quali);
	TYPETAG final_type = ty_query(type);
	while(final_type==TYPTR ){
		type=ty_query_pointer(type,&type_quali);;
		final_type=ty_query(type);
	}
	return final_type;
}




