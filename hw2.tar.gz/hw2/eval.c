#include<stdlib.h>
#include<stdio.h>
#include "expr.h"

long reduce_tree(EXPR parent_node, EXPR *tree, long val_array[26][100], int *expr_val, int index_tree)
    {
    BINOP_TYPE operation;
    long result;
    int var_as_index;
    long ref_pos;
    node_flag flag_temp;
    if(parent_node->tag == CONST_EXPR)
        {
            return parent_node->u.constant.val;
        }
    else if (parent_node->tag == BINOP_EXPR)
        {
            operation = parent_node->u.binop.op;

            switch (operation)
            {
                case PLUS:
                    result = reduce_tree(parent_node->u.binop.leftarg, tree, val_array, expr_val ,index_tree) + reduce_tree(parent_node->u.binop.rightarg, tree, val_array, expr_val ,index_tree);
                    break;
                case MINUS:
                    result = reduce_tree(parent_node->u.binop.leftarg, tree, val_array, expr_val ,index_tree) - reduce_tree(parent_node->u.binop.rightarg, tree, val_array, expr_val ,index_tree);
                    break;
                case TIMES:
                    result = reduce_tree(parent_node->u.binop.leftarg, tree, val_array, expr_val ,index_tree) * reduce_tree(parent_node->u.binop.rightarg, tree, val_array, expr_val ,index_tree);
                    break;
                case DIV:
                    result = reduce_tree(parent_node->u.binop.leftarg, tree, val_array, expr_val ,index_tree) / reduce_tree(parent_node->u.binop.rightarg, tree, val_array, expr_val ,index_tree);
                    break;
                case MOD:
                    result = reduce_tree(parent_node->u.binop.leftarg, tree, val_array, expr_val ,index_tree) % reduce_tree(parent_node->u.binop.rightarg, tree, val_array, expr_val ,index_tree);
                    break;
                default:
                    fprintf(stderr,"Unknown operator!\n");
                    break;
            }

            return result;
        }
    else if(parent_node->tag == VAR_EXPR)
    {
        var_as_index = parent_node->u.var.name - 'A';
        return val_array[var_as_index][1];

    }
    else if (parent_node->tag == UNOP_EXPR)
        {
        if (parent_node->u.unop.op == UNMINUS)
            {
            result = reduce_tree(parent_node->u.unop.arg, tree, val_array, expr_val ,index_tree);
            return (result *(-1));
            }
        else if (parent_node->u.unop.op == UNPLUS)
            {
            result = reduce_tree(parent_node->u.unop.arg, tree, val_array, expr_val ,index_tree);
            return (result);
            }
        else if (parent_node->u.unop.op == LINE_REF)
            {
            ref_pos = reduce_tree(parent_node->u.unop.arg, tree, val_array, expr_val ,index_tree);

            if (ref_pos == 0 || ref_pos >= index_tree)
                {
                fprintf(stderr,"Index %ld out of range\n",ref_pos);
                return 0;
                }
            flag_temp = tree[ref_pos]->flag;
            if (flag_temp == VALUE)
                {
                return tree[ref_pos]->value;
                }
            else if(flag_temp == NO_VALUE)
                {
                    //printf("\n Entered into no value\n");
                tree[ref_pos]->flag = WORKING;
                tree[ref_pos]->value = reduce_tree(tree[ref_pos], tree, val_array, expr_val ,index_tree);
                tree[ref_pos]->flag = VALUE;
                return tree[ref_pos]->value;
                }
            if (flag_temp == WORKING)
                {
                fprintf(stderr,"Circular reference found at line:%ld\n",ref_pos);
                exit(1);
                }
            }
        }
        return 0;
    }