#include<stdlib.h>
#include "expr.h"


EXPR make_const_node(int x)
    {
    EXPR node1;
    node1 = (EXPR)malloc(sizeof(TREE_NODE));
    node1->tag = CONST_EXPR;
    node1->u.constant.val = x;
    return node1;
    }

EXPR make_binop_node(char operator, EXPR node_left, EXPR node_right)
    {
    EXPR node2;
    node2 = (EXPR)malloc(sizeof(TREE_NODE));
    node2->tag = BINOP_EXPR;

    if (operator == '+')
        {
        node2->u.binop.op = PLUS;
        }
    else if (operator == '-')
        {
        node2->u.binop.op = MINUS;
        }
    else if (operator == '/')
        {
        node2->u.binop.op = DIV;
        }
    else if (operator == '*')
        {
        node2->u.binop.op = TIMES;
        }
    else if (operator == '%')
        {
        node2->u.binop.op = MOD;
        }

    node2->u.binop.leftarg = node_left;
    node2->u.binop.rightarg = node_right;
    return node2;
    }

EXPR make_var_node(char variable)
    {
    EXPR node3;
    node3 = (EXPR)malloc(sizeof(TREE_NODE));
    node3->tag = VAR_EXPR;
    node3->u.var.name = variable;
    //printf("\nthe variable name is %c\n",variable);
    return node3;
    }

EXPR make_unop_node(char operator, EXPR left, int line_num)
    {
    EXPR node4;
    node4 = (EXPR)malloc(sizeof(TREE_NODE));
    node4->tag = UNOP_EXPR;
    if (operator == '+')
        {
        node4->u.unop.op = UNPLUS;
        }
    else if (operator == '-')
        {
        node4->u.unop.op = UNMINUS;
        }
    else if (operator == '#')
        {
        node4->u.unop.op = LINE_REF;
        node4->u.unop.ref_line = line_num;
        }
    node4->u.unop.arg = left;
    return node4;
}

void build_main_tree(EXPR *tree, EXPR parent_node, int index)
    {
    tree[index] = parent_node;
    }