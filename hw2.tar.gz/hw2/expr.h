
typedef enum {CONST_EXPR, VAR_EXPR, UNOP_EXPR, BINOP_EXPR} EXPR_TAG_TYPE;

typedef enum {UNMINUS, UNPLUS, LINE_REF} UNOP_TYPE;

typedef enum {PLUS, MINUS, TIMES, DIV, MOD,} BINOP_TYPE;

typedef enum {NO_VALUE, WORKING, VALUE} node_flag;

typedef struct tn
    {
    EXPR_TAG_TYPE tag;
    int value;
    node_flag flag;
    union
        {
        struct
            {
            long val;
            }constant;
        struct
            {
            char name;
            }var;
        struct
            {
            UNOP_TYPE op;
            int ref_line;
            struct tn *arg;
            }unop;
        struct
            {
            BINOP_TYPE op;
            struct tn *leftarg , *rightarg;
            }binop;
        }u;
    }TREE_NODE, *EXPR;



EXPR make_const_node(int x);
EXPR make_binop_node(char operator, EXPR node_left, EXPR node_right);
void build_main_tree(EXPR *tree, EXPR parent_node, int index);
EXPR make_var_node(char variable);
EXPR make_unop_node(char operator, EXPR left, int line_num);
static long val_tab[26][100];


