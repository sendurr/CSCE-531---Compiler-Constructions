


long reduce_tree(EXPR parent_node, EXPR *tree, long val_array[26][100], int *expr_val, int index);


