#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "reference.h"


char get_opcode( char keyword[]);
char get_regno( char keyword[]);
int get_indirect_mem_ref( char keyword[]);

extern int yylex();
extern int yylineno;
extern char *yytext;
extern FILE *yyin;


int get_inden_loc(char iden[]);
char alloc_indentifier_check(char iden[]);
int alloc_instr_func(int i);
int opcode_mem_func(int i);
int opcode_reg_func(int i);
int opcode_brn_func(int i);
int opcode_lab_func(int i);
int opcode_io_func(int i);
int build_sym_tbl_lb( char iden[]);
int get_label_loc(char iden[]);
int get_label_stat(char iden[]);


struct flex_var
{
    int token;
    char text[20];
};

struct symbol_tbl
{
    char lab[50];
    int lab_point;
    char status[5];
    // status = 'r' is resolved
    // status = 'u' is unresolved
};

typedef struct
{
    unsigned char op_code;
    unsigned char mode: 5;
    unsigned char reg1no: 3;
    union
    {
        unsigned short loc;
        short imm_const;
        char reg2no;
    } arg2;
}instr;

struct flex_var flex_op[1000];
struct symbol_tbl symbol_array[1000];
instr instr_array[MAX_SIZE];

int mem_point =0 , instr_point =1 , symbol_tbl_point =0, error_count = 0;


FILE *fp;

enum mode_ref {register_mode ,direct_mode ,indirect_mode ,imm_constant_mode, branch_mode };
enum mode_ref mode_ref1;

int main(int argc, char **argv)
{
    int ntoken , vtoken , i=0 , array_len , arg_eq=0 , arg_ls=0 , arg_gr=0 , temp1;
    long int reg_exe[8], index, arg_1 ,arg_2;
    long int main_mem[1000];
    char file_nm[100];
    char unresolved[] ="u";

    char *ref[] = {NULL , "ALLOC_INSTR 1","OPCODE_MEM 2", "OPCODE_REG 3", "OPCODE_BRN 4", "OPCODE_IO 5", "REGISTER 6",
                   "INDIRECT 7", "INTEGER 8", "IDENTIFIER 9", "LABEL 10", "COMMA 11", "COLON 12"};

    strcpy(file_nm ,  argv[1]);
    fp =fopen(file_nm,"r");
    yyin = fp;
    ntoken = yylex();

    while(ntoken != 0)
    {
        if(ntoken == COMMENT) // code to remove comments
        {
            ntoken = yylex();
            while(ntoken != NEW_LINE && ntoken != 0)
            {
                ntoken = yylex();
            }
        }
        if (ntoken != NEW_LINE  && ntoken != 0) // code to remove only newline
        {
            flex_op[i].token = ntoken;
            strcpy(flex_op[i].text, yytext);
            i++;
        }
        ntoken = yylex();
    }

    //printf("Printing all the tokens from flex \n");

    array_len = i;

    // Testing to see if all tokens are identified
/*    for (i=0; i<array_len ; i++)
    {
        vtoken =flex_op[i].token;
        printf(" %d = %s  which is %s \n", flex_op[i].token, flex_op[i].text,ref[vtoken]);
    }*/

    // Loop through the token to arrive at the instruction set
    for (i=0; i<array_len ; i++)
    {
        switch(flex_op[i].token)
        {
            case ALLOC_INSTR:
            {
                i=alloc_instr_func(i);
                break;
            }
            case OPCODE_MEM:
            {
                i=opcode_mem_func(i);
                break;
            }
            case OPCODE_REG:
            {
                i=opcode_reg_func(i);
                break;
            }
            case OPCODE_BRN:
            {
                i=opcode_brn_func(i);
                break;
            }
            case LABEL:
            {
                i=opcode_lab_func(i);
                break;
            }
            case OPCODE_IO:
            {
                i=opcode_io_func(i);
                break;
            }
            default:
            {
                fprintf(stderr,"Syntax error : incorrect opcode! : %s \n",flex_op[i].text);
                error_count++;
            }
        }
    }

    // check for unresolved labels
    for (i=0; i<symbol_tbl_point;i++)
    {
        if(strcmp(symbol_array[i].status,unresolved)==0 )
        {
            fprintf(stderr,"Error! The label %s is unresolved  \n",symbol_array[i].lab);
            error_count++;
        }
    }

    if(error_count !=0)
    {
        fprintf(stderr,"%d Errors found! - exiting...\n",error_count);
        return 0;
    }
    // print symbol table
/*    printf("\n Printing symbol table details");
    printf("\n Symbol   mem_pointer  status \n");
    for (i=0; i<symbol_tbl_point;i++)
    {
        printf("%s    %d    %s \n", symbol_array[i].lab,symbol_array[i].lab_point, symbol_array[i].status);
    }

    // print instruction table
    printf("\n Printing instruction table details");
    printf("\n opcode   mode   reg1  location \n");
    for (i=1; i<instr_point;i++)
    {
        printf("%d    %d    %d   %d \n", instr_array[i].op_code , instr_array[i].mode , instr_array[i].reg1no , instr_array[i].arg2.loc);
    }*/

    // phase II  - execution
    for (i=1; i<instr_point;i++)
    {
        switch(instr_array[i].op_code)
        {
            case 0: //load
            {
                if (instr_array[i].mode == 1) // direct mode
                {
                    reg_exe[instr_array[i].reg1no] = main_mem[instr_array[i].arg2.loc];
                }
                else //indirect mode
                {
                    index= reg_exe[instr_array[i].arg2.loc];
                    reg_exe[instr_array[i].reg1no] = main_mem[index];
                }
                break;
            }
            case 1: //loada
            {
                if (instr_array[i].mode == 1) // direct mode
                {
                    reg_exe[instr_array[i].reg1no] = instr_array[i].arg2.loc;
                }
                else //indirect mode
                {
                    index= reg_exe[instr_array[i].arg2.loc];
                    reg_exe[instr_array[i].reg1no] = index;
                }
                break;
            }
            case 2: //store
            {
                if (instr_array[i].mode == 1) // direct mode
                {
                    main_mem[instr_array[i].arg2.loc] = reg_exe[instr_array[i].reg1no];
                }
                else //indirect mode
                {
                    index= reg_exe[instr_array[i].arg2.loc];
                    main_mem[index] = reg_exe[instr_array[i].reg1no];
                }
                break;
            }
            case 3: //move
            {
                if (instr_array[i].mode == 3) // immediate constant
                {
                    reg_exe[instr_array[i].reg1no] = instr_array[i].arg2.imm_const;
                }
                else //register
                {
                    reg_exe[instr_array[i].reg1no] = reg_exe[instr_array[i].arg2.reg2no];
                }
                break;
            }
            case 4: //add
            {
                if (instr_array[i].mode == 3) // immediate constant
                {
                    reg_exe[instr_array[i].reg1no] += instr_array[i].arg2.imm_const;
                }
                else //register
                {
                    reg_exe[instr_array[i].reg1no] += reg_exe[instr_array[i].arg2.reg2no];
                }
                break;
            }
            case 5: //sub
            {
                if (instr_array[i].mode == 3) // immediate constant
                {
                    reg_exe[instr_array[i].reg1no] -= instr_array[i].arg2.imm_const;
                }
                else //register
                {
                    reg_exe[instr_array[i].reg1no] -= reg_exe[instr_array[i].arg2.reg2no];
                }
                break;
            }
            case 6: //mul
            {
                if (instr_array[i].mode == 3) // immediate constant
                {
                    reg_exe[instr_array[i].reg1no] =  reg_exe[instr_array[i].reg1no] *
                                                      instr_array[i].arg2.imm_const;
                }
                else //register
                {
                    reg_exe[instr_array[i].reg1no] = reg_exe[instr_array[i].reg1no] *
                                                     reg_exe[instr_array[i].arg2.reg2no];
                }
                break;
            }
            case 7: //div
            {
                if (instr_array[i].mode == 3) // immediate constant
                {
                    reg_exe[instr_array[i].reg1no] =  reg_exe[instr_array[i].reg1no] /
                                                     instr_array[i].arg2.imm_const;
                }
                else //register
                {
                    reg_exe[instr_array[i].reg1no] = reg_exe[instr_array[i].reg1no] /
                                                    reg_exe[instr_array[i].arg2.reg2no];
                }
                break;
            }
            case 8: //mod
            {
                if (instr_array[i].mode == 3) // immediate constant
                {
                    reg_exe[instr_array[i].reg1no] =  reg_exe[instr_array[i].reg1no] %
                                                      instr_array[i].arg2.imm_const;
                }
                else //register
                {
                    reg_exe[instr_array[i].reg1no] = reg_exe[instr_array[i].reg1no] %
                                                     reg_exe[instr_array[i].arg2.reg2no];
                }
                break;
            }
            case 9: //cmp
            {
                arg_ls=arg_gr=arg_eq=0;
                arg_1 = reg_exe[instr_array[i].reg1no];

                if (instr_array[i].mode == 3) // immediate constant
                {
                     arg_2=instr_array[i].arg2.imm_const;
                }
                else //register
                {
                    arg_2=reg_exe[instr_array[i].arg2.reg2no];
                }

                if(arg_1 == arg_2)
                {
                    arg_eq=1; //equal
                }
                if(arg_1 < arg_2)
                {
                    arg_ls=1; // lesser
                }
                if(arg_1 > arg_2)
                {
                    arg_gr=1;// greater
                }
                //printf("\n less=%d , equal=%d, great=%d",arg_ls , arg_eq ,arg_gr);
                break;
            }
            case 10: //b
            {
                temp1 = instr_array[i].arg2.loc;
                //printf("\nthe location of 'b' is %d\n", temp1);
                i=temp1-1; // the minus adjusts the default increment by for loop
                break;
            }
            case 11: //blt
            {
                if (arg_ls == 1)
                {
                    temp1 = instr_array[i].arg2.loc;
                    //printf("\nthe location of 'blt' is %d\n", temp1);
                    i=temp1-1; // the minus adjusts the default increment by for loop
                }
                break;
            }
            case 12: //ble
            {
                if (arg_ls == 1 | arg_eq == 1)
                {
                    temp1 = instr_array[i].arg2.loc;
                    //printf("\nthe location of 'ble' is %d\n", temp1);
                    i=temp1-1; // the minus adjusts the default increment by for loop
                }
                break;
            }
            case 13: //bne
            {
                if (arg_ls == 1 | arg_gr == 1)
                {
                    temp1 = instr_array[i].arg2.loc;
                    //printf("\nthe location of 'bne' is %d\n", temp1);
                    i=temp1-1; // the minus adjusts the default increment by for loop
                }
                break;
            }
            case 14: //beq
            {
                if (arg_eq == 1)
                {
                    temp1 = instr_array[i].arg2.loc;
                    //printf("\nthe location of 'beq' is %d\n", temp1);
                    i=temp1-1; // the minus adjusts the default increment by for loop
                }
                break;
            }
            case 15: //bge
            {
                if (arg_eq == 1 | arg_gr == 1)
                {
                    temp1 = instr_array[i].arg2.loc;
                    //printf("\nthe location of 'bge' is %d\n", temp1);
                    i=temp1-1; // the minus adjusts the default increment by for loop
                }
                break;
            }
            case 16: //bgt
            {
                if (arg_gr == 1)
                {
                    temp1 = instr_array[i].arg2.loc;
                    //printf("\nthe location of 'bgt' is %d\n", temp1);
                    i=temp1-1; // the minus adjusts the default increment by for loop
                }
                break;
            }
            case 17: // read
            {
                //printf("\n It entered read loop\n");
                scanf("%ld", &reg_exe[instr_array[i].reg1no]);
                break;
            }
            case 18: // write
            {
                //printf("\n It entered write loop\n");
                printf("%ld\n", reg_exe[instr_array[i].reg1no]);
                break;
            }
            default:
            {
                fprintf(stderr," Instruction set error!  \n");
                error_count++;
            }
        }
    }
    return 0;
}

// rules for input / output instructions

int opcode_io_func(int i)
{
   // printf("\n %s ",flex_op[i].text);
    instr_array[instr_point].op_code= get_opcode(flex_op[i].text);
    i=i+1;
    if (flex_op[i].token == REGISTER)// register
    {
        //printf("\n %s ",flex_op[i].text);
        instr_array[instr_point].reg1no=get_regno(flex_op[i].text);
        mode_ref1 = register_mode;
        instr_array[instr_point].mode= mode_ref1;
        instr_point = instr_point +1;
    }
    else
    {
        fprintf(stderr,"Syntax error : register missing! \n");
        error_count++;
    }
    return i;
};

// rules for label instructions

int opcode_lab_func(int i)
{
    //printf("\n %s ",flex_op[i].text);
    instr_array[instr_point].op_code= get_opcode(flex_op[i].text);
    i=i+1;
    if (flex_op[i].token == COLON)// label for branching
    {
        //printf("\n %c ",flex_op[i].text[0]);
        // decrement the index to point to label and not colon
        i=i-1;
        build_sym_tbl_lb(flex_op[i].text);
        i=i+1;
    }
    else
    {
        fprintf(stderr,"Syntax error : colon  missing! \n");
        error_count++;
    }
    return i;
};

// rules for branch instructions

int opcode_brn_func(int i)
{
   // printf("\n %s ",flex_op[i].text);
    instr_array[instr_point].op_code= get_opcode(flex_op[i].text);
    i=i+1;
    if (flex_op[i].token == LABEL)// label for branching
    {
       // printf("\n %s ",flex_op[i].text);
        instr_array[instr_point].arg2.loc=get_label_loc(flex_op[i].text);

        mode_ref1 = branch_mode;
        instr_array[instr_point].mode= mode_ref1;
        instr_point = instr_point +1;
    }
    else
    {
        fprintf(stderr,"Syntax error : label missing! \n");
        error_count++;
    }
    return i;
};

// rules for register instructions

int opcode_reg_func(int i)
{
    //printf("\n %s ",flex_op[i].text);
    instr_array[instr_point].op_code= get_opcode(flex_op[i].text);
    i=i+1;
    if (flex_op[i].token == REGISTER)//1st register
    {
        //printf("\n %s ",flex_op[i].text);
        instr_array[instr_point].reg1no=get_regno(flex_op[i].text);
        i=i+1;
        if (flex_op[i].token == COMMA)
        {
            //printf("\n %s ",flex_op[i].text);
            i=i+1;
            if (flex_op[i].token == REGISTER) //2nd register
            {
                //printf("\n %s ",flex_op[i].text);
                instr_array[instr_point].arg2.reg2no=get_regno(flex_op[i].text);
                mode_ref1 = register_mode;
                instr_array[instr_point].mode= mode_ref1;
                instr_point = instr_point +1;
            }
            else if (flex_op[i].token == INTEGER) //immediate constant
            {
                //printf("\n %s ",flex_op[i].text);
                instr_array[instr_point].arg2.imm_const=atoi(flex_op[i].text);
                mode_ref1 = imm_constant_mode;
                instr_array[instr_point].mode= mode_ref1;
                instr_point = instr_point +1;
            }
            else
            {
                fprintf(stderr,"register or immediate constant missing! \n");
                error_count++;
            }
        }
        else
        {
            fprintf(stderr,"Syntax error : comma missing! \n");
            error_count++;
        }
    }
    else
    {
        fprintf(stderr,"Syntax error : register missing! \n");
        error_count++;
    }
    return i;
};

// rules for memory access instructions

int opcode_mem_func(int i)
{
    //printf("\n %s ",flex_op[i].text);
    instr_array[instr_point].op_code= get_opcode(flex_op[i].text);
    i=i+1;
    if (flex_op[i].token == REGISTER)
    {
        //printf("\n %s ",flex_op[i].text);
        instr_array[instr_point].reg1no=get_regno(flex_op[i].text);
        i=i+1;
        if (flex_op[i].token == COMMA)
        {
            //printf("\n %s ",flex_op[i].text);
            i=i+1;
            if (flex_op[i].token == IDENTIFIER) //direct memory reference
            {
                //printf("\n %s ",flex_op[i].text);
                instr_array[instr_point].arg2.loc=get_inden_loc(flex_op[i].text);
                mode_ref1 = direct_mode;
                instr_array[instr_point].mode= mode_ref1;
                instr_point = instr_point +1;
            }
            else if (flex_op[i].token == INDIRECT) //indirect memory reference
            {
                //printf("\n %s ",flex_op[i].text);
                instr_array[instr_point].arg2.loc=get_indirect_mem_ref(flex_op[i].text);
                mode_ref1 = indirect_mode;
                instr_array[instr_point].mode= mode_ref1;
                instr_point = instr_point +1;
            }
            else
            {
                fprintf(stderr,"Identifier or indirect memory reference missing! \n");
                error_count++;
            }
        }
        else
        {
            fprintf(stderr,"Syntax error : comma missing! \n");
            error_count++;
        }
    }
    else
    {
        fprintf(stderr,"Syntax error : register missing! \n");
        error_count++;
    }
    return i;
};


// rules for alloc instruction
int alloc_instr_func(int i)
{
    char not_applicable[4] = "n";
    //printf("\n %s ",flex_op[i].text);
    i=i+1;
    if (flex_op[i].token == IDENTIFIER)
    {
        //printf("\n %s ",flex_op[i].text);
        if ((alloc_indentifier_check(flex_op[i].text)) == 'y')
        {
            fprintf(stderr,"Alloc indentifier %s already assigned!\n",flex_op[i].text);
            error_count++;
        }
        strcpy(symbol_array[symbol_tbl_point].lab,flex_op[i].text);
        i=i+1;
        if (flex_op[i].token == COMMA)
        {
            //printf("\n %s ",flex_op[i].text);
            i=i+1;
            if (flex_op[i].token == INTEGER)
            {
                //printf("\n %s ",flex_op[i].text);
                symbol_array[symbol_tbl_point].lab_point=mem_point;
                strcpy(symbol_array[symbol_tbl_point].status , not_applicable);
                mem_point = mem_point + atoi(flex_op[i].text);
                symbol_tbl_point = symbol_tbl_point +1;
            }
            else
            {
                fprintf(stderr,"Alloc error integer!\n");
                error_count++;
            }
        }
        else
        {
           // printf("\n default size 1");
            symbol_array[symbol_tbl_point].lab_point=mem_point;
            strcpy(symbol_array[symbol_tbl_point].status , not_applicable);
            mem_point = mem_point + 1;
            symbol_tbl_point = symbol_tbl_point + 1;
            i = i - 1;
        }
    }
    else
    {
        fprintf(stderr,"Alloc error identifier!\n");
        error_count++;
    }
    return i;
};

// bulid the symbol table for the label
int build_sym_tbl_lb( char iden[])
{
    int lab_stat , start_loc , i , next_loc;
    char resolved[] ="r";

    lab_stat = get_label_stat(iden);

    switch (lab_stat)
    {
        case 0:
        {
            strcpy(symbol_array[symbol_tbl_point].lab,iden);
            symbol_array[symbol_tbl_point].lab_point=instr_point;
            strcpy(symbol_array[symbol_tbl_point].status,resolved);
            symbol_tbl_point = symbol_tbl_point +1;
            break;
        }
        case 1:
        {
            //fetch the index of the first match from bottom
            for (i=symbol_tbl_point-1;i>=0;i--)
            {
                if (strcmp(iden , symbol_array[i].lab) ==0)
                {
                    break;
                }
            }
            // now backpatch the instruction array
            start_loc = symbol_array[i].lab_point;
            strcpy(symbol_array[i].status,resolved);
            symbol_array[i].lab_point = instr_point;
            i = start_loc;
            do
            {
                next_loc = instr_array[i].arg2.loc;
                instr_array[i].arg2.loc = instr_point;
                i=next_loc;
            }while(i!=0);
            break;
        }
        case 2:
        {
            fprintf(stderr,"Error: Label %s already resolved!\n", iden);
            error_count++;
        }
    }
    return 0;
};

// get the location of label from symbol table
int get_label_loc( char iden[])
{
    int lab_stat , temp_loc , i;
    char unresolved[] ="u";

    lab_stat = get_label_stat(iden);

    switch (lab_stat)
    {
        case 0:
        {
            strcpy(symbol_array[symbol_tbl_point].lab,iden);
            symbol_array[symbol_tbl_point].lab_point=instr_point;
            strcpy(symbol_array[symbol_tbl_point].status,unresolved);
            symbol_tbl_point = symbol_tbl_point +1;
            return 0;
        }
        case 1:
        {
            //fetch the index of the first match from bottom
            for (i=symbol_tbl_point-1;i>=0;i--)
            {
                if (strcmp(iden , symbol_array[i].lab) ==0)
                {
                    break;
                }
            }
            temp_loc = symbol_array[i].lab_point;
            symbol_array[i].lab_point=instr_point;
            return temp_loc;
        }
        case 2:
        {
            //fetch the index of the first match from bottom
            for (i=symbol_tbl_point-1;i>=0;i--)
            {
                if (strcmp(iden , symbol_array[i].lab) ==0)
                {
                    break;
                }
            }
            return symbol_array[i].lab_point;
        }
    }
    return 0;
};

// get the status of label from symbol table
int get_label_stat( char iden[])
{
    int i , lab_stat = 0 ;
    char resolved[] = "r";
    // lab_stat = 0 = not found
    // lab_stat = 1 = found & unresolved
    // lab_stat = 2 = found & resolved

    for (i=0;i<symbol_tbl_point;i++)
    {
        if (strcmp(iden , symbol_array[i].lab) ==0)
        {
            if(strcmp(resolved, symbol_array[i].status) ==0)
            {
                lab_stat =2;
            }
            else
            {
                lab_stat =1;
            }
            break;
        }
    }
    return lab_stat;
}

// get the location of identifier from symbol table
int get_inden_loc( char iden[])
{
    int i;
    for (i=0;i<symbol_tbl_point;i++)
    {
        if (strcmp(iden , symbol_array[i].lab) ==0)
        {

            return symbol_array[i].lab_point;
        }
    }
    fprintf(stderr,"Indetifier %s not declared!\n", iden);
    error_count++;
    return 0;
};

// check to see if alloc identifier is declareds
char alloc_indentifier_check(char iden[])
{
    int i;
    for (i=0;i<symbol_tbl_point;i++)
    {
        if (strcmp(iden , symbol_array[i].lab) ==0)
        {

            return 'y';
        }
    }
    return 'n';
};


char get_opcode( char keyword[])
{
    int len;
    char i = 0;
    char *op_code_ref[]= {"load","loada","store", "move" , "add" , "sub" , "mul" , "div" , "mod"  , "cmp" , "b" , "blt" , "ble" , "bne" ,"beq", "bge" , "bgt","read","write"};
    char x;

    for (i=0;i<19;i++)
    {
        if (strcmp(keyword , op_code_ref[i]) ==0)
        {
            break;
        }
    }
    //x=i+'a';
    return i;
};

char get_regno( char keyword[])
{
    int  len;
    char *reg_ref[]= {"r0" , "r1", "r2" , "r3" , "r4" , "r5" , "r6" , "r7"};
    char x , i;

    for (i=0;i<8;i++)
    {
        if (strcmp(keyword , reg_ref[i]) ==0)
        {
            break;
        }
    }
    //x=i+'0';
    return i;
};


int get_indirect_mem_ref( char keyword[])
{
    int  len , i;
    char *reg_ref[]= {"(r0)" , "(r1)", "(r2)" , "(r3)" , "(r4)" , "(r5)" , "(r6)" , "(r7)"};
    char x;

    for (i=0;i<8;i++)
    {
        if (strcmp(keyword , reg_ref[i]) ==0)
        {
            break;
        }
    }
    //x=i+'0';
    return i;
};




